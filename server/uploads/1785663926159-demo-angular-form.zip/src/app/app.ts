import { CommonModule } from '@angular/common';
import { Component, inject, OnInit, signal } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, ReactiveFormsModule, CommonModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit {
  protected readonly title = signal('demo-angular-form');
  private _fb = inject(FormBuilder);
  userForm!: FormGroup;
  readonly genderGroup = signal(['Male', 'Female']);
  ngOnInit(): void {
    this.initForm();
  }

  initForm() {
    this.userForm = this._fb.group({
      name: [''],
      gender: [''],
    });
  }
  submit() {
    console.log('FormValue ==>', this.userForm.getRawValue());
  }
}
